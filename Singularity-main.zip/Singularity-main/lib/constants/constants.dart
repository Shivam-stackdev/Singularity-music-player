const hiveBoxes = [
  {'name': 'settings', 'limit': false},
  {'name': 'downloads', 'limit': false},
  {'name': 'stats', 'limit': false},
  {'name': 'Favorite Songs', 'limit': false},
  {'name': 'cache', 'limit': true},
  {'name': 'ytlinkcache', 'limit': true},
];
